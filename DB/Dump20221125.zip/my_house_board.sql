-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: my_house
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `BOARD_ID` int NOT NULL AUTO_INCREMENT,
  `USER_SEQ` int NOT NULL,
  `TITLE` varchar(500) DEFAULT NULL,
  `CONTENT` text,
  `REG_DT` datetime DEFAULT NULL,
  `read_count` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`BOARD_ID`),
  KEY `FK_USER_idx` (`USER_SEQ`),
  CONSTRAINT `FK_USER` FOREIGN KEY (`USER_SEQ`) REFERENCES `users` (`USER_SEQ`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (1,3,'구해줘홈즈 위치기반서비스 이용약관(2022/06/08) 개정 안내 ','<h2>안녕하세요. 구해줘홈즈 입니다.</h2><p>&nbsp;</p><p>항상 구해줘홈즈 서비스를 이용해주시는 이용자 여러분께 진심으로 감사드리며</p><p>구해줘홈즈 위치기반서비스 이용약관 개정에 대한 사전 안내 말씀 드립니다.</p><p>&nbsp;</p><p>이용자분께서는 변경되는 구해줘홈즈 위치기반서비스 이용약관 내용을 확인해주시기를 부탁 드립니다.</p><p>&nbsp;</p><p>항상 구해줘홈즈 이용해 주시는 여러 이용자분들께 감사의 말씀 드리며, 앞으로도 더 나은 서비스를</p><p>제공드리도록 노력하겠습니다.</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p><br>&nbsp;</p>','2022-11-25 08:57:27',1),(2,3,'구해줘홈즈 개인정보처리방침 (2022/11/20) 개정안내 ','<h2>안녕하세요. 구해줘홈즈 입니다.</h2><p>&nbsp;</p><p>항상 구해줘홈즈 서비스를 이용해주시는 이용자 여러분께 진심으로 감사드리며</p><p>구해줘홈즈 위치기반서비스 이용약관 개정에 대한 사전 안내 말씀 드립니다.</p><p>&nbsp;</p><p>이용자분께서는 변경되는 구해줘홈즈 위치기반서비스 이용약관 내용을 확인해주시기를 부탁 드립니다.</p><p>&nbsp;</p><p>항상 구해줘홈즈 이용해 주시는 여러 이용자분들께 감사의 말씀 드리며, 앞으로도 더 나은 서비스를</p><p>제공드리도록 노력하겠습니다.</p>','2022-11-25 08:58:55',0),(3,3,'구해줘홈즈 월세 지원 제도, 최대 1년 월세 지원','<p>구해줘홈즈 월세 지원 제도, 최대 1년 월세 지원</p>','2022-11-25 08:59:58',0),(4,3,'아파트를 구하는 새로운 자세, 아파트는 구해줘홈즈부터','<p>아파트를 구하는 새로운 자세, 아파트는 구해줘홈즈부터아파트를 구하는 새로운 자세, 아파트는 구해줘홈즈부터</p>','2022-11-25 09:00:20',0);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-25  9:09:25
